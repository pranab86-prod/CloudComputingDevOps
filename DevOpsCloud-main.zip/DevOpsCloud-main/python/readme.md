sudo ln -s /usr/bin/python3 /usr/bin/python	Create soft link
sudo rm /usr/bin/python	Remove old link
