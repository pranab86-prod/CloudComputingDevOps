<img width="880" height="465" alt="image" src="https://github.com/user-attachments/assets/7d94e71d-3e9b-410d-b90e-6e8365b79aaf" />




<img width="853" height="392" alt="image" src="https://github.com/user-attachments/assets/84356b99-6e7c-4c0f-a7d8-2eb7a66fe904" />



