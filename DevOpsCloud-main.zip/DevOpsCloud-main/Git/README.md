# Set your name
git config --global user.name "Your Name"
# Set your email
git config --global user.email "you@example.com"
